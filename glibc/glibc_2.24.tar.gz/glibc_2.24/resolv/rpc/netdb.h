/* This is a dummy file for <rpc/netdb.h>, which is included by <netdb.h>.
   This file is installed when the C library does not support the SunRPC
   interfaces (including 'struct rpcent' et al) at all.  */
