#!/bin/bash
builddir=`dirname "$0"`
GCONV_PATH="${builddir}/iconvdata"

usage () {
  echo "usage: $0 [--tool=strace] PROGRAM [ARGUMENTS...]" 2>&1
  echo "       $0 --tool=valgrind PROGRAM [ARGUMENTS...]" 2>&1
  exit 1
}

toolname=default
while test $# -gt 0 ; do
  case "$1" in
    --tool=*)
      toolname="${1:7}"
      shift
      ;;
    --*)
      usage
      ;;
    *)
      break
      ;;
  esac
done

if test $# -eq 0 ; then
  usage
fi

case "$toolname" in
  default)
    exec   env GCONV_PATH="${builddir}"/iconvdata LOCPATH="${builddir}"/localedata LC_ALL=C  "${builddir}"/elf/ld-linux-x86-64.so.2 --library-path "${builddir}":"${builddir}"/math:"${builddir}"/elf:"${builddir}"/dlfcn:"${builddir}"/nss:"${builddir}"/nis:"${builddir}"/rt:"${builddir}"/resolv:"${builddir}"/mathvec:"${builddir}"/support:"${builddir}"/crypt:"${builddir}"/nptl ${1+"$@"}
    ;;
  strace)
    exec strace  -EGCONV_PATH=/tmp/t/glibc_2.31/build/iconvdata  -ELOCPATH=/tmp/t/glibc_2.31/build/localedata  -ELC_ALL=C  /tmp/t/glibc_2.31/build/elf/ld-linux-x86-64.so.2 --library-path /tmp/t/glibc_2.31/build:/tmp/t/glibc_2.31/build/math:/tmp/t/glibc_2.31/build/elf:/tmp/t/glibc_2.31/build/dlfcn:/tmp/t/glibc_2.31/build/nss:/tmp/t/glibc_2.31/build/nis:/tmp/t/glibc_2.31/build/rt:/tmp/t/glibc_2.31/build/resolv:/tmp/t/glibc_2.31/build/mathvec:/tmp/t/glibc_2.31/build/support:/tmp/t/glibc_2.31/build/crypt:/tmp/t/glibc_2.31/build/nptl ${1+"$@"}
    ;;
  valgrind)
    exec env GCONV_PATH=/tmp/t/glibc_2.31/build/iconvdata LOCPATH=/tmp/t/glibc_2.31/build/localedata LC_ALL=C valgrind  /tmp/t/glibc_2.31/build/elf/ld-linux-x86-64.so.2 --library-path /tmp/t/glibc_2.31/build:/tmp/t/glibc_2.31/build/math:/tmp/t/glibc_2.31/build/elf:/tmp/t/glibc_2.31/build/dlfcn:/tmp/t/glibc_2.31/build/nss:/tmp/t/glibc_2.31/build/nis:/tmp/t/glibc_2.31/build/rt:/tmp/t/glibc_2.31/build/resolv:/tmp/t/glibc_2.31/build/mathvec:/tmp/t/glibc_2.31/build/support:/tmp/t/glibc_2.31/build/crypt:/tmp/t/glibc_2.31/build/nptl ${1+"$@"}
    ;;
  container)
    exec env GCONV_PATH=/tmp/t/glibc_2.31/build/iconvdata LOCPATH=/tmp/t/glibc_2.31/build/localedata LC_ALL=C  /tmp/t/glibc_2.31/build/elf/ld-linux-x86-64.so.2 --library-path /tmp/t/glibc_2.31/build:/tmp/t/glibc_2.31/build/math:/tmp/t/glibc_2.31/build/elf:/tmp/t/glibc_2.31/build/dlfcn:/tmp/t/glibc_2.31/build/nss:/tmp/t/glibc_2.31/build/nis:/tmp/t/glibc_2.31/build/rt:/tmp/t/glibc_2.31/build/resolv:/tmp/t/glibc_2.31/build/mathvec:/tmp/t/glibc_2.31/build/support:/tmp/t/glibc_2.31/build/crypt:/tmp/t/glibc_2.31/build/nptl /tmp/t/glibc_2.31/build/support/test-container env GCONV_PATH=/tmp/t/glibc_2.31/build/iconvdata LOCPATH=/tmp/t/glibc_2.31/build/localedata LC_ALL=C  /tmp/t/glibc_2.31/build/elf/ld-linux-x86-64.so.2 --library-path /tmp/t/glibc_2.31/build:/tmp/t/glibc_2.31/build/math:/tmp/t/glibc_2.31/build/elf:/tmp/t/glibc_2.31/build/dlfcn:/tmp/t/glibc_2.31/build/nss:/tmp/t/glibc_2.31/build/nis:/tmp/t/glibc_2.31/build/rt:/tmp/t/glibc_2.31/build/resolv:/tmp/t/glibc_2.31/build/mathvec:/tmp/t/glibc_2.31/build/support:/tmp/t/glibc_2.31/build/crypt:/tmp/t/glibc_2.31/build/nptl ${1+"$@"}
    ;;
  *)
    usage
    ;;
esac
