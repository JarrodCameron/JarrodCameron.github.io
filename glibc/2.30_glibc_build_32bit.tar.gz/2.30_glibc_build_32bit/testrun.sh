#!/bin/bash
builddir=`dirname "$0"`
GCONV_PATH="${builddir}/iconvdata"

usage () {
  echo "usage: $0 [--tool=strace] PROGRAM [ARGUMENTS...]" 2>&1
  echo "       $0 --tool=valgrind PROGRAM [ARGUMENTS...]" 2>&1
  exit 1
}

toolname=default
while test $# -gt 0 ; do
  case "$1" in
    --tool=*)
      toolname="${1:7}"
      shift
      ;;
    --*)
      usage
      ;;
    *)
      break
      ;;
  esac
done

if test $# -eq 0 ; then
  usage
fi

case "$toolname" in
  default)
    exec   env GCONV_PATH="${builddir}"/iconvdata LOCPATH="${builddir}"/localedata LC_ALL=C  "${builddir}"/elf/ld-linux.so.2 --library-path "${builddir}":"${builddir}"/math:"${builddir}"/elf:"${builddir}"/dlfcn:"${builddir}"/nss:"${builddir}"/nis:"${builddir}"/rt:"${builddir}"/resolv:"${builddir}"/mathvec:"${builddir}"/support:"${builddir}"/crypt:"${builddir}"/nptl ${1+"$@"}
    ;;
  strace)
    exec strace  -EGCONV_PATH=/tmp/glibc_2.30/build/iconvdata  -ELOCPATH=/tmp/glibc_2.30/build/localedata  -ELC_ALL=C  /tmp/glibc_2.30/build/elf/ld-linux.so.2 --library-path /tmp/glibc_2.30/build:/tmp/glibc_2.30/build/math:/tmp/glibc_2.30/build/elf:/tmp/glibc_2.30/build/dlfcn:/tmp/glibc_2.30/build/nss:/tmp/glibc_2.30/build/nis:/tmp/glibc_2.30/build/rt:/tmp/glibc_2.30/build/resolv:/tmp/glibc_2.30/build/mathvec:/tmp/glibc_2.30/build/support:/tmp/glibc_2.30/build/crypt:/tmp/glibc_2.30/build/nptl ${1+"$@"}
    ;;
  valgrind)
    exec env GCONV_PATH=/tmp/glibc_2.30/build/iconvdata LOCPATH=/tmp/glibc_2.30/build/localedata LC_ALL=C valgrind  /tmp/glibc_2.30/build/elf/ld-linux.so.2 --library-path /tmp/glibc_2.30/build:/tmp/glibc_2.30/build/math:/tmp/glibc_2.30/build/elf:/tmp/glibc_2.30/build/dlfcn:/tmp/glibc_2.30/build/nss:/tmp/glibc_2.30/build/nis:/tmp/glibc_2.30/build/rt:/tmp/glibc_2.30/build/resolv:/tmp/glibc_2.30/build/mathvec:/tmp/glibc_2.30/build/support:/tmp/glibc_2.30/build/crypt:/tmp/glibc_2.30/build/nptl ${1+"$@"}
    ;;
  *)
    usage
    ;;
esac
