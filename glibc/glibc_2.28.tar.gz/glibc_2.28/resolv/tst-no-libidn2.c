/* Compiled into an empty shared object.  Used by
   tst-resolv-ai_idn-nolibidn2 to disable libidn2.  */
